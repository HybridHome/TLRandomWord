# TLRandomWord
使用 Cordova 和 Vue.js 创建移动应用。该实例展示如何使用 Cordova 和 Vue.js 开发一个简单的生成随机单词的移动应用
